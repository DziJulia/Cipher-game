import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Assigment_03 {
//                                               Cipher  Game
//                                          Julia Dobrovodska  3061278
//---------------------------------------------------------------------------------------------------------------------

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		Random rnd = new Random();    		  		
		//menu for user
        System.out.println("Menu :\n 1) Normal mode \n 2) Test mode");
        System.out.print ( "Selection: " );          
//user selection if he put number different than 1 or 2 ask again
        String user_Selection;
        while(true) {
        	user_Selection= in.next();
        	if(!user_Selection.equals("1") & !user_Selection.equals("2"))
        	{        		
        		 System.err.println ( "Unrecognized option please enter again number 1 or 2: \n"
        		 		+ "Menu :\n 1) Normal mode \n 2) Test mode \n") ;
        	}
        	else { break;}
        }
        String ChoosedParagraph;
        int number;
        //if user pick 1 normal mode if user pick 2 test mode
        	 switch (user_Selection) {
          case "1":
            System.out.println ( "You picked Normal mode \n" );
            number = rnd.nextInt(6);
           ChoosedParagraph = getParagraph(number);
            decryption(getEncrypt(ChoosedParagraph));
            break;
          case "2":
            System.out.println ( "You picked test mode \n" );
            	//printing truncaded paragraphs either first line or 50 characters whichever is shorter.... WHOLE WORDS!!
            	System.out.print("0.  ");
            	truncadedParagraph(getParagraph(0));
            	System.out.print("1.  ");
            	truncadedParagraph(getParagraph(1));
            	System.out.print("2.  ");
            	truncadedParagraph(getParagraph(2));
            	System.out.print("3.  ");
            	truncadedParagraph(getParagraph(3));
            	System.out.print("4.  ");
            	truncadedParagraph(getParagraph(4));
            	System.out.print("5.  ");
            	truncadedParagraph(getParagraph(5));
            	System.out.println("Please choose your paragraph number 0 - 5: ");
            	   while(true) {
            		   number = in.nextInt();
            	       if(number < 0 || number > 5)
            	       {
           		        System.err.println ( "Ooops, unrecognized option please enter again: ") ;
                  	}  
                  	else { break;}
           }
            	     ChoosedParagraph = getParagraph(number);
                     //     System.out.println(ChoosedParagraph);
            	     //    decryption of paragraph
            	      decryption(getEncrypt(ChoosedParagraph));  
            break;
            //if number or character is wrong it print out err
          default:   System.err.println ( " Ooops , unrecognized option please enter again: ") ;
    }     
}
		
	//getting my paragraph truncated
	public static void truncadedParagraph(String strArray) {
		//variable maxChar 
		int maxChar=50;
		//separator space for my paragraphs
		String SEPARATOR = " ";
		String[] arr = strArray.split("\n");
		if (arr != null)
		{
	    // if the first paragraph lengt is longer than 50 characters than print the first 50-character limit 
			if(arr[0].length() > maxChar) {
				if (arr[0].substring(0, maxChar + 1).contains(SEPARATOR)) 
				{
					//trying to print out whole word so if space is't the next character and the paragraph is longer tha 50 characters it print ony
					//till last word
			            strArray.substring(0, strArray.substring(0, maxChar+1).lastIndexOf(SEPARATOR));
			            System.out.println(strArray.substring(0, strArray.substring(0, maxChar+1).lastIndexOf(SEPARATOR)));
				} 
			}
			//if it's shorther or within 50 characters print first character
			else {
	        // get first line using : arr[index]
	        System.out.println(arr[0]);
			}
		}
	}	
	
public static void decryption( String strArray){
	Scanner in = new Scanner(System.in);
	 System.out.println();
	 System.out.println("Enter two letters: \n"
	 		+ "First letter is what you want to replace, and second letter is what you want to replace it with.\n"
	 		+ " Start decrypting: ");
	 //start time when the paragraph is shown..
	 double startTime = System.currentTimeMillis();
	 System.out.println();
	 //creating list to store inputs
	 List<String> userInputs = new ArrayList<String>();
	 // creating a list to store my random numbers for help...
     List<String> randomNumbers = new ArrayList<String>();
	 int help = 0;
	 //storing my paragraph so i can keep my original one
	 String original = "";
	 original = original.replaceAll(original, strArray);
	  while(true) {
             if(original != getDecrypt(original))
             {            	 
	                String user_input = in.next();	           
	                if(user_input.length() == 1)
	                {	                	
	                	String userUp = user_input.toUpperCase();
	                	if(original.contains(userUp))
	                	{	                		
	                		int index = original.indexOf(userUp);
	                		char originalLetter = strArray.charAt(index);
	                		String finalLetter = String.valueOf(originalLetter);
	              			//replacing the letter with original one
	                		original = original.replace(userUp, finalLetter);
		              		for (int counter = 0; counter < userInputs.size(); counter++){
		              			//removing the existing pair witch matches user input
		              			if(userInputs.get(counter).contains(user_input)) 
		              			{
//		              				System.out.println("Found it in userInputs " + counter);
		              				userInputs.remove(counter);
		              			}
		                	}	            	
	                	}
	                }
	            else {
	                switch (user_input.toUpperCase()) {
	               //help max 5 times
	                case "HELP" :
	                	if(help != 5) 
	                	{	                		
	                	userHelp(randomNumbers);
	                	help++;
	                	int maxHelp = 5;
	                	System.out.println("\n You can use help " + (maxHelp-help) + " times.");
	                	
	                	}
	                	if(help >=5) 
	                	{	                		
	                	 System.out.println("\n Sorry, you used all the help , maximum help was 5 times");	 
	                	}
	                	break;
	                	//reset button
	                case "RESET":
	                	System.out.println("Your paragraph was reset, all pairs too you can start from beginning, \n"
	                			+ "but remeber your time is still running for your final score");
	                	original = "";
	                	original = original.replaceAll(original, strArray);
	                	userInputs.clear();
	                	break;
             }
	                // if user inputs contained either 1 or 2 letter what is already in my list 
	                boolean same = true;
	                if (!"help".equalsIgnoreCase(user_input) & !"reset".equalsIgnoreCase(user_input) & user_input.length()==2)
	                {
		                if(same) 
		                {
		                	// Check for first letter:
		              		for (int counter = 0; counter < userInputs.size(); counter++) {
		              			//removing the existing pair witch matches user input
		              			if(userInputs.get(counter).substring(0,1).contains(user_input.substring(0,1))) 
		              			{
//		              				System.out.println("Found it in userInputs " + counter);
		              				String indexoffirst = userInputs.get(counter).substring(1,2).toUpperCase();
		              				if(original.contains(indexoffirst)) 
		              				{		              					
		              					int index1 = original.indexOf(indexoffirst);
		              					char originalLetter1 = strArray.charAt(index1);
		    	                		String finalLetter1 = String.valueOf(originalLetter1);
		    	              			//replacing the letter with original one
		    	                		original = original.replace(indexoffirst, finalLetter1);
		              				}
//		              				System.out.println(" first "+  indexoffirst);
		              				userInputs.remove(counter);
		              				break;
		              			}
		              		}
		              		// Check for second letter:
		              			for (int counter = 0; counter < userInputs.size(); counter++) {
		              				
		              			if(userInputs.get(counter).substring(1,2).contains(user_input.substring(1,2)))
		              			{
//		              				System.out.println("Found it in userInputs " + counter);
		              				String indexoffirst = userInputs.get(counter).substring(1,2).toUpperCase();
		              				if(original.contains(indexoffirst)) 
		              				{		              					
		              					int index2 = original.indexOf(indexoffirst);
		              					char originalLetter2 = strArray.charAt(index2);
		    	                		String finalLetter1 = String.valueOf(originalLetter2);
		    	              			//replacing the letter with original one
		    	                		original = original.replace(indexoffirst, finalLetter1);
		              				}
//		              				System.out.println("second" + indexoffirst);
		              				userInputs.remove(counter);
		              			  break;
		                	    }
		              	}
		            same = true;
		           }
		            same =false;
	                userInputs.add(user_input);
	                Iterator<String> iter = userInputs.iterator();
	                String first_letter = "";
	                String second_letter = "";
	                int count= 1;
	                while (iter.hasNext()) {
	                	String choice = iter.next();	
	                	// first letter
	                	first_letter = choice.substring(0, 1);
	                	first_letter = first_letter.toLowerCase();
	                	// second letter
	                	second_letter = choice.substring(1, 2);
	              		second_letter = second_letter.toUpperCase();
	              		System.out.print(first_letter + " > " + second_letter + " | ");
	              		// printing on next line when the list is longer than 10
	              		 if(count % 10 == 0)
	              		 {
	                           System.out.println();
	                     }
	              	    count++;
	                 }         
	               for (int i=0; i<original.length(); i++) {
	                     original = original.replaceAll(first_letter, second_letter);
	                 }          
	               }
	                if (!"help".equalsIgnoreCase(user_input) & !"reset".equalsIgnoreCase(user_input) & user_input.length()>=3)
	                {
	                	
	                	System.err.println("\n Ooops , too long. Please enter again 2 letters, help or reset. \n");
	                }
	             }
       System.out.println("\n" + original+ "\n");
       //print this only while user doing inputs
      if(original != getDecrypt(original))
      {    	  
       System.out.println("Enter 2 letters: \n"
       		+ "You can also use help typing 'help' " + (5-help) + " more times \n"
       				+ "or reset typing 'reset' to reset all the paragraphs and pairs\n"); 
      }
             }
  else break;
  }
	  //time and score counting	
	 double endTime = System.currentTimeMillis();
	 double time= (endTime - startTime )/ 1000;
	 double score = 1000 - time;
	 if(score < 0)
	 {
		 score = 0;
	 }
	 {System.out.println("You won");
	 System.out.println("Your score is " + Math.round(score));
	 }
in.close();
}
	public static String getParagraph(int index)
	{
		//my paragraphs
		String str1 = "When you want something, \n "
	             + "all the universe conspires in helping you\n"
	             + " to achieve it.";
		String str2 = "Don't waste your time with explanations: \n"
	             + "people only hear what they want to hear.";
		String str3 = "Be brave. Take risks. \n"
	             + "Nothing can substitute experience.";
		String str4 = "There is only one thing that makes a dream \n"
	             + "impossible to achieve: the fear of failure.";
		String str5 =    "Life was always a matter of waiting for the right moment to act.\n"
	             + "You drown not by falling into a river, but by staying submerged in it.";
		String str6 =   "The world as we have created it is a process of our thinking.\n"
	             + " It cannot be changed without changing our thinking.";
		//putting all paragraphs in upper case
		str1= str1.toUpperCase();
		str2= str2.toUpperCase();
		str3= str3.toUpperCase();
		str4= str4.toUpperCase();
		str5= str5.toUpperCase();
		str6= str6.toUpperCase();
		//putting it all in array
		String[] strArray = {str1,str2,str3,str4,str5,str6};
	
		
		return strArray[index];
    }
  public static void userHelp( List<String> randomNumbers)
  {	  
    	Random rnd = new Random();  
    	//creating random number
         int number_help = rnd.nextInt(25);
        String numberString = Integer.toString(number_help);
        boolean isnotrandom = true;                          //creating new variable for my no repeat while loop
    	while (isnotrandom) {                                // this loop is for the numbers to not repeat
  			isnotrandom = false;
  			number_help = rnd.nextInt(25);                    // if number repeats it will generate new number
  		    numberString = Integer.toString(number_help);
  			for (int y =0; y<randomNumbers.size(); y++) {                              
  		       if(randomNumbers.contains(numberString) ) 
  		       {
  		    	   
  			    isnotrandom = true ;  
  			   }
  	        }
        }
             randomNumbers.add(numberString);
//             System.out.println(randomNumbers);
        	 String[] strHelp = {"q = A","w = B","e = C","r = D","t = E","y = F","u = G","i = H","o = I","p = J","a = K",
        			 "s = L","d = M","f = N","g = O","h = P","j = R","k = S","l = T","z = U","x = V","c = W","v = X","b = Y",
        			 "n = Q","m = Z"};   
        		 System.out.println("Help : " + strHelp[number_help]);
}
	
		public static String getEncrypt(String strArray) 
		{		
		//getting encrypted my parahraph	
			for (int i=0; i<strArray.length(); i++) {
				strArray = strArray.replaceAll("A", "q");
				strArray = strArray.replaceAll("B", "w");
				strArray = strArray.replaceAll("C", "e");
				strArray = strArray.replaceAll("D", "r");
				strArray = strArray.replaceAll("E", "t");
				strArray = strArray.replaceAll("F", "y");
				strArray = strArray.replaceAll("G", "u");
				strArray = strArray.replaceAll("H", "i");
				strArray = strArray.replaceAll("I", "o");
				strArray = strArray.replaceAll("J", "p");
				strArray = strArray.replaceAll("K", "a");
				strArray = strArray.replaceAll("L", "s");
				strArray = strArray.replaceAll("M", "d");
				strArray = strArray.replaceAll("N", "f");
				strArray = strArray.replaceAll("O", "g");
				strArray = strArray.replaceAll("P", "h");
				strArray = strArray.replaceAll("R", "j");
				strArray = strArray.replaceAll("S", "k");
				strArray = strArray.replaceAll("T", "l");
				strArray = strArray.replaceAll("U", "z");
				strArray = strArray.replaceAll("V", "x");
				strArray = strArray.replaceAll("W", "c");
				strArray = strArray.replaceAll("X", "v");
				strArray = strArray.replaceAll("Y", "b");
				strArray = strArray.replaceAll("Q", "n");
				strArray = strArray.replaceAll("Z", "m");
				  
				}
			System.out.println(strArray);
			return strArray;
		}
		public static String getDecrypt(String strArray) 
		{		
			//getting decrypted my parahraph	
			for (int i=0; i<strArray.length(); i++) {
				strArray = strArray.replaceAll("q", "A");
				strArray = strArray.replaceAll("w", "B");
				strArray = strArray.replaceAll("e", "C");
				strArray = strArray.replaceAll("r", "D");
				strArray = strArray.replaceAll("t", "E");
				strArray = strArray.replaceAll("y", "F");
				strArray = strArray.replaceAll("u", "G");
				strArray = strArray.replaceAll("i", "H");
				strArray = strArray.replaceAll("o", "I");
				strArray = strArray.replaceAll("p", "J");
				strArray = strArray.replaceAll("a", "K");
				strArray = strArray.replaceAll("s", "L");
				strArray = strArray.replaceAll("d", "M");
				strArray = strArray.replaceAll("f", "N");
				strArray = strArray.replaceAll("g", "O");
				strArray = strArray.replaceAll("h", "P");
				strArray = strArray.replaceAll("j", "R");
				strArray = strArray.replaceAll("k", "S");
				strArray = strArray.replaceAll("l", "T");
				strArray = strArray.replaceAll("z", "U");
				strArray = strArray.replaceAll("x", "V");
				strArray = strArray.replaceAll("c", "W");
				strArray = strArray.replaceAll("v", "X");
				strArray = strArray.replaceAll("b", "Y");
				strArray = strArray.replaceAll("n", "Q");
				strArray = strArray.replaceAll("m", "Z");
				  
				}
			return strArray;
		}       
	}

